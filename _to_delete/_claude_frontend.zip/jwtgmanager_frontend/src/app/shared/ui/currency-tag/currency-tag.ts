import { Component, input } from '@angular/core';
import { Currency } from '../../../core/data/models';

@Component({
  selector: 'app-currency-tag',
  templateUrl: './currency-tag.html',
  styleUrl: './currency-tag.scss',
})
export class CurrencyTag {
  readonly currency = input.required<Currency>();
}
