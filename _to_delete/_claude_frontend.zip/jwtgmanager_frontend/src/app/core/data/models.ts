export type Currency = 'COINS' | 'AMBER';
export type CurrencyFilter = Currency | 'ALL';
export type RarityCode = 'C' | 'R' | 'E' | 'L' | 'T';

export interface User {
  id: string;
  email: string;
  pseudo: string;
  role: string;
}

export interface AuthResponse {
  token: string;
  user: User;
}

export interface Rarity {
  code: RarityCode;
  label: string;
  sortOrder: number;
}

export interface Hybrid {
  hybridId: number;
  name: string;
  componentIds: number[];
}

export interface SpeciesProgress {
  speciesId: number;
  name: string;
  rarityCode: RarityCode;
  hybrid: boolean;
  unlocked: boolean;
  lvl10: number;
  lvl20: number;
  lvl30: number;
  lvl40: number;
  targetLvl40: number;
  currency: Currency;
  unitCost: number | null;
  units: number;
  unitsNeeded: number;
  progress: number;
  invested: number;
  remaining: number;
}

export interface SpeciesUpdate {
  unlocked: boolean;
  lvl10: number;
  lvl20: number;
  lvl30: number;
  lvl40: number;
  targetLvl40: number;
}

export interface Settings {
  weeklyCoins: number;
  weeklyAmber: number;
  defaultTarget: number;
}

export interface Investment {
  id: number;
  speciesId: number;
  speciesName: string;
  fromLevel: number | null;
  toLevel: number;
  quantity: number;
  cost: number;
  currency: Currency;
  investedOn: string;
}

export interface NewInvestment {
  speciesId: number;
  fromLevel: number | null;
  toLevel: number;
  quantity: number;
  investedOn: string;
}

export interface Projection {
  remaining: number;
  weeklyIncome: number;
  weeks: number | null;
  finishDate: string | null;
}

export interface Dashboard {
  currencyFilter: CurrencyFilter;
  summary: {
    completion: number;
    done: number;
    tracked: number;
    lvl40: number;
    lvl40Target: number;
    coinsInvested: number;
    coinsRemaining: number;
    amberInvested: number;
    amberRemaining: number;
  };
  previousCompletion: number | null;
  hybridsUnlocked: number;
  hybridsTotal: number;
  byRarity: {
    code: RarityCode;
    label: string;
    completion: number;
    done: number;
    tracked: number;
    coinsRemaining: number;
    amberRemaining: number;
  }[];
  closest: {
    speciesId: number;
    name: string;
    rarityCode: RarityCode;
    progress: number;
    remaining: number;
    currency: Currency;
  }[];
  coins: Projection;
  amber: Projection;
}

export interface HistoryPoint {
  day: string;
  completion: number;
  lvl40Count: number;
  lvl40Target: number;
}

/** Multiplicateur de coût de chaque palier (niv. 10, 20, 30, 40). */
export const LEVEL_MULTIPLIER: Record<number, number> = { 10: 1, 20: 2, 30: 4, 40: 8 };
