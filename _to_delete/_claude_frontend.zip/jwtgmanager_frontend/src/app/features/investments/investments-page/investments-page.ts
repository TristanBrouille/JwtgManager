import { Component, computed, inject, signal, viewChild } from '@angular/core';
import { CollectionService } from '../../../core/data/collection.service';
import { InvestmentsService } from '../../../core/data/investments.service';
import { NewInvestment, Settings } from '../../../core/data/models';
import { problemMessage } from '../../../core/http/problem';
import { shortNumber } from '../../../shared/format/format';
import { BudgetForm } from '../ui/budget-form/budget-form';
import { InvestmentForm } from '../ui/investment-form/investment-form';
import { InvestmentLog } from '../ui/investment-log/investment-log';

@Component({
  selector: 'app-investments-page',
  imports: [InvestmentForm, BudgetForm, InvestmentLog],
  templateUrl: './investments-page.html',
  styleUrl: './investments-page.scss',
})
export class InvestmentsPage {
  private readonly collectionService = inject(CollectionService);
  private readonly investmentsService = inject(InvestmentsService);
  private readonly form = viewChild.required(InvestmentForm);

  protected readonly species = this.collectionService.collection.value;
  protected readonly settings = computed(() =>
    this.collectionService.settings.hasValue()
      ? this.collectionService.settings.value()
      : undefined,
  );
  protected readonly investments = this.investmentsService.investments.value;

  protected readonly saving = signal(false);
  protected readonly savingBudget = signal(false);
  protected readonly cancelling = signal<number | null>(null);
  protected readonly message = signal<string | null>(null);
  protected readonly error = signal<string | null>(null);

  protected async record(investment: NewInvestment): Promise<void> {
    this.saving.set(true);
    this.error.set(null);
    try {
      const saved = await this.investmentsService.record(investment);
      this.message.set(
        `${saved.speciesName} : +${saved.quantity} niveau ${saved.toLevel} enregistré (${shortNumber(saved.cost)} ${
          saved.currency === 'COINS' ? 'pièces' : 'ambre'
        })`,
      );
      this.form().reset();
    } catch (e) {
      this.error.set(problemMessage(e, 'Investissement refusé'));
    } finally {
      this.saving.set(false);
    }
  }

  protected async cancel(id: number): Promise<void> {
    this.cancelling.set(id);
    this.error.set(null);
    try {
      await this.investmentsService.cancel(id);
      this.message.set(
        'Investissement annulé : les spécimens sont revenus à leur palier de départ.',
      );
    } catch (e) {
      this.error.set(problemMessage(e, 'Annulation impossible'));
    } finally {
      this.cancelling.set(null);
    }
  }

  protected async saveBudget(settings: Settings): Promise<void> {
    this.savingBudget.set(true);
    this.error.set(null);
    try {
      await this.collectionService.saveSettings(settings);
      this.message.set('Budget hebdomadaire enregistré.');
    } catch (e) {
      this.error.set(problemMessage(e, 'Budget non enregistré'));
    } finally {
      this.savingBudget.set(false);
    }
  }
}
