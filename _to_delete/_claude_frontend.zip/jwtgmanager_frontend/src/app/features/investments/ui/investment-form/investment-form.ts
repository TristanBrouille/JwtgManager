import { Component, computed, input, output, signal } from '@angular/core';
import { FormField, form, max, min, required, submit, validate } from '@angular/forms/signals';
import { LEVEL_MULTIPLIER, NewInvestment, SpeciesProgress } from '../../../../core/data/models';
import { CurrencyTag } from '../../../../shared/ui/currency-tag/currency-tag';
import { fullNumber } from '../../../../shared/format/format';

interface InvestmentModel {
  species: string;
  from: string;
  to: string;
  quantity: number;
  date: string;
}

const today = (): string => new Date().toISOString().slice(0, 10);

/** Formulaire « Nouvelle montée » : choisit une espèce, un palier de départ et d'arrivée, et affiche le coût. */
@Component({
  selector: 'app-investment-form',
  imports: [FormField, CurrencyTag],
  templateUrl: './investment-form.html',
  styleUrl: './investment-form.scss',
})
export class InvestmentForm {
  readonly species = input.required<SpeciesProgress[]>();
  readonly saving = input(false);
  readonly recorded = output<NewInvestment>();

  protected readonly model = signal<InvestmentModel>({
    species: '',
    from: 'new',
    to: '40',
    quantity: 1,
    date: today(),
  });

  private readonly byName = computed(
    () => new Map(this.species().map((s) => [s.name.toLowerCase(), s])),
  );

  protected readonly investmentForm = form(this.model, (p) => {
    required(p.species, { message: 'Choisissez une espèce' });
    validate(p.species, (ctx) =>
      ctx.value() && !this.byName().has(ctx.value().trim().toLowerCase())
        ? { kind: 'unknownSpecies', message: 'Espèce inconnue : choisissez-la dans la liste' }
        : undefined,
    );
    validate(p.to, (ctx) => {
      const from = ctx.valueOf(p.from);
      return from !== 'new' && Number(ctx.value()) <= Number(from)
        ? { kind: 'levelOrder', message: 'Le niveau cible doit être supérieur au niveau de départ' }
        : undefined;
    });
    required(p.quantity, { message: 'Quantité obligatoire' });
    min(p.quantity, 1, { message: 'Au moins 1' });
    max(p.quantity, 99, { message: '99 maximum' });
    required(p.date, { message: 'Date obligatoire' });
  });

  protected readonly selected = computed(
    () => this.byName().get(this.model().species.trim().toLowerCase()) ?? null,
  );

  /** Problème bloquant connu avant envoi (stock insuffisant, coût inconnu). */
  protected readonly blocker = computed(() => {
    const s = this.selected();
    if (!s) {
      return null;
    }
    const { from, quantity } = this.model();
    if (s.unitCost === null) {
      return `Coût unitaire inconnu pour ${s.name} en ${s.currency === 'COINS' ? 'pièces' : 'ambre'}.`;
    }
    if (from !== 'new') {
      const available = s[`lvl${from}` as 'lvl10' | 'lvl20' | 'lvl30'];
      if (available < quantity) {
        return `Vous n'avez que ${available} ${s.name} au niveau ${from}.`;
      }
    }
    return null;
  });

  protected readonly cost = computed(() => {
    const s = this.selected();
    const { from, to, quantity } = this.model();
    if (!s || s.unitCost === null || this.investmentForm().invalid()) {
      return null;
    }
    const steps =
      LEVEL_MULTIPLIER[Number(to)] - (from === 'new' ? 0 : LEVEL_MULTIPLIER[Number(from)]);
    return { amount: fullNumber(steps * s.unitCost * quantity), currency: s.currency };
  });

  protected onSubmit(event: Event): void {
    event.preventDefault();
    void submit(this.investmentForm, async () => {
      const s = this.selected();
      if (!s || this.blocker()) {
        return undefined;
      }
      const { from, to, quantity, date } = this.model();
      this.recorded.emit({
        speciesId: s.speciesId,
        fromLevel: from === 'new' ? null : Number(from),
        toLevel: Number(to),
        quantity,
        investedOn: date,
      });
      return undefined;
    });
  }

  /** Réinitialise le formulaire après un enregistrement réussi (en gardant la date). */
  reset(): void {
    this.model.update((m) => ({ ...m, species: '', quantity: 1 }));
    this.investmentForm().reset();
  }
}
