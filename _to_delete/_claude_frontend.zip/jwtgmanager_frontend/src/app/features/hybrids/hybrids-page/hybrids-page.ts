import { Component, computed, inject, signal } from '@angular/core';
import { Toolbar, ToolbarWidget } from '@angular/aria/toolbar';
import { CatalogService } from '../../../core/data/catalog.service';
import { CollectionService } from '../../../core/data/collection.service';
import { problemMessage } from '../../../core/http/problem';
import { HybridCard, HybridEntry } from '../ui/hybrid-card/hybrid-card';

type Filter = 'all' | 'open' | 'locked';

@Component({
  selector: 'app-hybrids-page',
  imports: [Toolbar, ToolbarWidget, HybridCard],
  templateUrl: './hybrids-page.html',
  styleUrl: './hybrids-page.scss',
})
export class HybridsPage {
  private readonly catalog = inject(CatalogService);
  private readonly collection = inject(CollectionService);

  protected readonly filter = signal<Filter>('all');
  protected readonly error = signal<string | null>(null);
  protected readonly filters: { value: Filter; label: string }[] = [
    { value: 'all', label: 'Tous' },
    { value: 'open', label: 'Débloqués' },
    { value: 'locked', label: 'À débloquer' },
  ];

  private readonly entries = computed<HybridEntry[]>(() => {
    const byId = this.collection.byId();
    return this.catalog.hybrids
      .value()
      .map((h) => ({
        hybrid: byId.get(h.hybridId),
        components: h.componentIds.map((id) => byId.get(id)).filter((c) => c !== undefined),
      }))
      .filter((e): e is HybridEntry => e.hybrid !== undefined)
      .sort(
        (a, b) =>
          Number(a.hybrid.unlocked) - Number(b.hybrid.unlocked) ||
          a.hybrid.name.localeCompare(b.hybrid.name, 'fr'),
      );
  });

  protected readonly visible = computed(() => {
    const f = this.filter();
    return this.entries().filter((e) => f === 'all' || (f === 'open') === e.hybrid.unlocked);
  });

  protected readonly unlockedCount = computed(
    () => this.entries().filter((e) => e.hybrid.unlocked).length,
  );
  protected readonly total = computed(() => this.entries().length);

  protected async toggle(change: { speciesId: number; unlocked: boolean }): Promise<void> {
    this.error.set(null);
    try {
      await this.collection.update(change.speciesId, { unlocked: change.unlocked });
    } catch (e) {
      this.error.set(problemMessage(e, 'Modification refusée'));
      this.collection.collection.reload();
    }
  }
}
