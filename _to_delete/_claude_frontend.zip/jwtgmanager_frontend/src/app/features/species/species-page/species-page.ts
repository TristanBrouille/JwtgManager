import { Component, computed, inject, signal } from '@angular/core';
import { Toolbar, ToolbarWidget } from '@angular/aria/toolbar';
import { CatalogService } from '../../../core/data/catalog.service';
import { CollectionService } from '../../../core/data/collection.service';
import { RarityCode, SpeciesProgress } from '../../../core/data/models';
import { problemMessage } from '../../../core/http/problem';
import { SpeciesChange, SpeciesTable } from '../ui/species-table/species-table';

type Status = '' | 'done' | 'progress' | 'todo' | 'nocost';
type Sort = 'rest' | 'progress' | 'name' | 'cost';

@Component({
  selector: 'app-species-page',
  imports: [Toolbar, ToolbarWidget, SpeciesTable],
  templateUrl: './species-page.html',
  styleUrl: './species-page.scss',
})
export class SpeciesPage {
  private readonly collection = inject(CollectionService);
  protected readonly catalog = inject(CatalogService);

  protected readonly query = signal('');
  protected readonly rarity = signal<RarityCode | ''>('');
  protected readonly status = signal<Status>('');
  protected readonly sort = signal<Sort>('rest');
  protected readonly error = signal<string | null>(null);
  protected readonly loading = this.collection.collection.isLoading;

  protected readonly rows = computed(() => {
    const q = this.query().trim().toLowerCase();
    const rarity = this.rarity();
    const status = this.status();
    const list = this.collection.collection
      .value()
      .filter(
        (s) =>
          (!rarity || s.rarityCode === rarity) &&
          (!q || s.name.toLowerCase().includes(q)) &&
          matches(s, status),
      );
    return [...list].sort(comparator(this.sort()));
  });

  protected readonly total = computed(() => this.collection.collection.value().length);

  protected async onChange(change: SpeciesChange): Promise<void> {
    this.error.set(null);
    try {
      await this.collection.update(change.speciesId, change.patch);
    } catch (e) {
      this.error.set(problemMessage(e, 'Modification refusée'));
      this.collection.collection.reload();
    }
  }

  protected onQuery(event: Event): void {
    this.query.set((event.target as HTMLInputElement).value);
  }

  protected onStatus(event: Event): void {
    this.status.set((event.target as HTMLSelectElement).value as Status);
  }

  protected onSort(event: Event): void {
    this.sort.set((event.target as HTMLSelectElement).value as Sort);
  }
}

function matches(s: SpeciesProgress, status: Status): boolean {
  switch (status) {
    case 'done':
      return s.targetLvl40 > 0 && s.progress >= 1;
    case 'progress':
      return s.progress > 0 && s.progress < 1;
    case 'todo':
      return s.units === 0 && s.unitCost !== null;
    case 'nocost':
      return s.unitCost === null;
    default:
      return true;
  }
}

function comparator(sort: Sort): (a: SpeciesProgress, b: SpeciesProgress) => number {
  switch (sort) {
    case 'name':
      return (a, b) => a.name.localeCompare(b.name, 'fr');
    case 'progress':
      return (a, b) => b.progress - a.progress;
    case 'cost':
      return (a, b) => (a.unitCost ?? Infinity) - (b.unitCost ?? Infinity);
    default:
      return (a, b) =>
        Number(a.progress >= 1) - Number(b.progress >= 1) || a.remaining - b.remaining;
  }
}
