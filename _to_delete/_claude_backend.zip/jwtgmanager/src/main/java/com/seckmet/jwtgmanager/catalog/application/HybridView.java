package com.seckmet.jwtgmanager.catalog.application;

import java.util.List;

public record HybridView(int hybridId, String name, List<Integer> componentIds) {
}
