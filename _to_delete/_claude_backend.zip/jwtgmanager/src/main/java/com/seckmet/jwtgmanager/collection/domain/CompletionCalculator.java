package com.seckmet.jwtgmanager.collection.domain;

import com.seckmet.jwtgmanager.shared.domain.Currency;

import com.seckmet.jwtgmanager.shared.domain.Level;

import java.util.OptionalLong;

/** Calcule l'avancement d'une espèce suivie par un joueur. */
public final class CompletionCalculator {
    private CompletionCalculator() {
    }

    public static SpeciesProgress progress(PlayerSpecies species, UnitCosts costs) {
        Currency currency = species.currency();
        OptionalLong unitCost = costs.in(currency);
        long units = species.counts().units();
        long needed = species.unitsNeeded();
        double progress = needed == 0 ? 1.0 : Math.min(1.0, (double) units / needed);
        long cost = unitCost.orElse(0);
        long invested = units * cost;
        long remaining = Math.max(0, needed - units) * cost;
        return new SpeciesProgress(currency, unitCost, units, needed, progress, invested, remaining);
    }

    /** Coût d'une montée de niveau : (multiplicateur cible − multiplicateur départ) × coût unitaire × quantité. */
    public static long levelUpCost(java.util.Optional<Level> from, Level to, int quantity, long unitCost) {
        int fromMultiplier = from.map(Level::multiplier).orElse(0);
        return (long) (to.multiplier() - fromMultiplier) * unitCost * quantity;
    }
}
