package com.seckmet.jwtgmanager.collection.application;

public record SettingsView(long weeklyCoins, long weeklyAmber, int defaultTarget) {
}
