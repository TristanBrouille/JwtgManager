package com.seckmet.jwtgmanager.collection.infrastructure;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.util.UUID;

@Entity
@Table(name = "player_settings")
public class PlayerSettingsJpaEntity {
    @Id
    @Column(name = "user_id")
    private UUID userId;
    @Column(name = "weekly_coins", nullable = false)
    private Integer weeklyCoins;
    @Column(name = "weekly_amber", nullable = false)
    private Integer weeklyAmber;
    @Column(name = "default_target", nullable = false)
    private Short defaultTarget;

    protected PlayerSettingsJpaEntity() {
    }

    PlayerSettingsJpaEntity(UUID userId, int weeklyCoins, int weeklyAmber, short defaultTarget) {
        this.userId = userId;
        this.weeklyCoins = weeklyCoins;
        this.weeklyAmber = weeklyAmber;
        this.defaultTarget = defaultTarget;
    }

    public UUID getUserId() { return userId; }
    public Integer getWeeklyCoins() { return weeklyCoins; }
    public Integer getWeeklyAmber() { return weeklyAmber; }
    public Short getDefaultTarget() { return defaultTarget; }
}
