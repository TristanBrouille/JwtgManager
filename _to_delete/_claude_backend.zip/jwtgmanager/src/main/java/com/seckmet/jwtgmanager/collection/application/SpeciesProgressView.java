package com.seckmet.jwtgmanager.collection.application;

public record SpeciesProgressView(
        int speciesId, String name, String rarityCode, boolean hybrid,
        boolean unlocked, int lvl10, int lvl20, int lvl30, int lvl40, int targetLvl40,
        String currency, Long unitCost, long units, long unitsNeeded,
        double progress, long invested, long remaining) {

    public boolean tracked() {
        return targetLvl40 > 0;
    }

    public boolean done() {
        return tracked() && progress >= 1.0;
    }

    public long countedUnits() {
        return Math.min(units, unitsNeeded);
    }
}
