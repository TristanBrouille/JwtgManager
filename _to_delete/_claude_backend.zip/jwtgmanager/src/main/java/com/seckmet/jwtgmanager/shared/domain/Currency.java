package com.seckmet.jwtgmanager.shared.domain;

/** Monnaie de paiement : pièces si l'espèce est débloquée, ambre sinon. */
public enum Currency {
    COINS, AMBER;

    public static Currency forUnlocked(boolean unlocked) {
        return unlocked ? COINS : AMBER;
    }
}
