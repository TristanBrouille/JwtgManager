package com.seckmet.jwtgmanager.catalog.application;

public record SpeciesView(int id, String name, String rarityCode, Long coinCost, Long amberCost,
                          boolean hybrid, boolean defaultUnlocked) {
}
