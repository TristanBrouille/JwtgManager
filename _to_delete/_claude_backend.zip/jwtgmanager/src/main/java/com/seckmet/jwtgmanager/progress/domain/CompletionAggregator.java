package com.seckmet.jwtgmanager.progress.domain;

import com.seckmet.jwtgmanager.shared.domain.Currency;

import java.time.LocalDate;
import java.util.Collection;
import java.util.Optional;

/** Agrège l'avancement des espèces suivies et projette la date de fin selon le budget. */
public final class CompletionAggregator {
    private CompletionAggregator() {
    }

    /** Complétion = somme des unités détenues (plafonnées à l'objectif) / somme des unités visées. */
    public static CompletionSummary summarize(Collection<ProgressLine> lines) {
        long counted = 0, needed = 0, l40 = 0, l40Target = 0;
        long coinsInvested = 0, coinsRemaining = 0, amberInvested = 0, amberRemaining = 0;
        int done = 0;
        for (ProgressLine l : lines) {
            counted += l.countedUnits();
            needed += l.unitsNeeded();
            l40 += Math.min(l.lvl40(), l.target());
            l40Target += l.target();
            if (l.done()) {
                done++;
            }
            if (l.currency() == Currency.COINS) {
                coinsInvested += l.invested();
                coinsRemaining += l.remaining();
            } else {
                amberInvested += l.invested();
                amberRemaining += l.remaining();
            }
        }
        double completion = needed == 0 ? 0 : (double) counted / needed;
        return new CompletionSummary(completion, done, lines.size(), l40, l40Target,
                coinsInvested, coinsRemaining, amberInvested, amberRemaining);
    }

    /** Nombre de semaines pour financer {@code remaining} avec {@code weeklyIncome}, vide si le revenu est nul. */
    public static Optional<Long> weeksToFinish(long remaining, long weeklyIncome) {
        if (remaining <= 0) {
            return Optional.of(0L);
        }
        if (weeklyIncome <= 0) {
            return Optional.empty();
        }
        return Optional.of((remaining + weeklyIncome - 1) / weeklyIncome);
    }

    public static Optional<LocalDate> finishDate(LocalDate today, Optional<Long> weeks) {
        return weeks.map(today::plusWeeks);
    }
}
