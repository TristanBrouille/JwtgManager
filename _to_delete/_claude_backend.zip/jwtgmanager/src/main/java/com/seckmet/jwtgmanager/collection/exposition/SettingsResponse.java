package com.seckmet.jwtgmanager.collection.exposition;

public record SettingsResponse(long weeklyCoins, long weeklyAmber, int defaultTarget) {
}
