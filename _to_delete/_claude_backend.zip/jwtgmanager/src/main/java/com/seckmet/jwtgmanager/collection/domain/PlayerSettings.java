package com.seckmet.jwtgmanager.collection.domain;

import com.seckmet.jwtgmanager.shared.domain.InvalidLevelUpException;

import java.util.Objects;
import java.util.UUID;

/** Réglages du joueur : revenus hebdomadaires et objectif par défaut. */
public class PlayerSettings {
    private final UUID userId;
    private long weeklyCoins;
    private long weeklyAmber;
    private int defaultTarget;

    public PlayerSettings(UUID userId, long weeklyCoins, long weeklyAmber, int defaultTarget) {
        this.userId = Objects.requireNonNull(userId);
        update(weeklyCoins, weeklyAmber, defaultTarget);
    }

    public static PlayerSettings defaults(UUID userId) {
        return new PlayerSettings(userId, 0, 0, 3);
    }

    public void update(long weeklyCoins, long weeklyAmber, int defaultTarget) {
        if (weeklyCoins < 0 || weeklyAmber < 0) {
            throw new InvalidLevelUpException("Les revenus hebdomadaires ne peuvent pas être négatifs");
        }
        if (defaultTarget < 0 || defaultTarget > PlayerSpecies.MAX_TARGET) {
            throw new InvalidLevelUpException("L'objectif par défaut doit être compris entre 0 et " + PlayerSpecies.MAX_TARGET);
        }
        this.weeklyCoins = weeklyCoins;
        this.weeklyAmber = weeklyAmber;
        this.defaultTarget = defaultTarget;
    }

    public UUID userId() { return userId; }
    public long weeklyCoins() { return weeklyCoins; }
    public long weeklyAmber() { return weeklyAmber; }
    public int defaultTarget() { return defaultTarget; }
}
