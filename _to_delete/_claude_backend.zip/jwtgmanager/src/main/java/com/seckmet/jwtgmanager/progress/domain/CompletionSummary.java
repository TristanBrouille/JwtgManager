package com.seckmet.jwtgmanager.progress.domain;

/** Indicateurs agrégés d'un ensemble d'espèces suivies. */
public record CompletionSummary(double completion, int done, int tracked, long lvl40, long lvl40Target,
                                long coinsInvested, long coinsRemaining, long amberInvested, long amberRemaining) {
}
