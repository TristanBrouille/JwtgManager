package com.seckmet.jwtgmanager.collection.domain;

import com.seckmet.jwtgmanager.shared.domain.Currency;

import java.util.OptionalLong;

/** Coût d'un palier unitaire d'une espèce, en pièces et en ambre (null = inconnu). */
public record UnitCosts(Long coins, Long amber) {

    public OptionalLong in(Currency currency) {
        Long value = currency == Currency.COINS ? coins : amber;
        return value == null || value == 0 ? OptionalLong.empty() : OptionalLong.of(value);
    }
}
