package com.seckmet.jwtgmanager.collection.domain;

import com.seckmet.jwtgmanager.shared.domain.Currency;

import java.util.OptionalLong;

/**
 * Avancement d'une espèce. {@code unitCost} vide = coût inconnu : investi et reste valent alors 0.
 */
public record SpeciesProgress(Currency currency, OptionalLong unitCost, long units, long unitsNeeded,
                              double progress, long invested, long remaining) {

    public boolean done() {
        return progress >= 1.0;
    }

    /** Unités comptées pour la complétion (plafonnées à l'objectif). */
    public long countedUnits() {
        return Math.min(units, unitsNeeded);
    }
}
