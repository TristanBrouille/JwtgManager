package com.seckmet.jwtgmanager.collection.exposition;

public record SpeciesProgressResponse(
        int speciesId, String name, String rarityCode, boolean hybrid,
        boolean unlocked, int lvl10, int lvl20, int lvl30, int lvl40, int targetLvl40,
        String currency, Long unitCost, long units, long unitsNeeded,
        double progress, long invested, long remaining) {
}
