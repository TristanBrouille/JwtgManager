package com.seckmet.jwtgmanager.collection.domain;

import com.seckmet.jwtgmanager.shared.domain.Currency;
import com.seckmet.jwtgmanager.shared.domain.Level;
import org.junit.jupiter.api.Test;

import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;

class CompletionCalculatorTest {

    private static final UUID USER = UUID.randomUUID();

    @Test
    void unlockedSpecies_isPaidInCoins() {
        PlayerSpecies triceratops = new PlayerSpecies(USER, 1, true, new SpecimenCounts(0, 0, 0, 3), 3, null);
        SpeciesProgress p = CompletionCalculator.progress(triceratops, new UnitCosts(100L, null));
        assertThat(p.currency()).isEqualTo(Currency.COINS);
        assertThat(p.invested()).isEqualTo(2400);
        assertThat(p.remaining()).isZero();
        assertThat(p.progress()).isEqualTo(1.0);
    }

    @Test
    void lockedSpecies_isPaidInAmber() {
        PlayerSpecies euoplo = new PlayerSpecies(USER, 2, false, new SpecimenCounts(1, 0, 0, 1), 3, null);
        SpeciesProgress p = CompletionCalculator.progress(euoplo, new UnitCosts(1000L, 25000L));
        assertThat(p.currency()).isEqualTo(Currency.AMBER);
        assertThat(p.invested()).isEqualTo(9 * 25000);
        assertThat(p.remaining()).isEqualTo((24 - 9) * 25000L);
        assertThat(p.progress()).isCloseTo(9.0 / 24, within(1e-9));
    }

    @Test
    void unknownCost_countsProgressButNoMoney() {
        PlayerSpecies dodo = new PlayerSpecies(USER, 3, false, new SpecimenCounts(0, 1, 0, 0), 3, null);
        SpeciesProgress p = CompletionCalculator.progress(dodo, new UnitCosts(5950L, null));
        assertThat(p.unitCost()).isEmpty();
        assertThat(p.invested()).isZero();
        assertThat(p.remaining()).isZero();
        assertThat(p.units()).isEqualTo(2);
    }

    @Test
    void progress_isCappedAtOne() {
        PlayerSpecies ps = new PlayerSpecies(USER, 4, true, new SpecimenCounts(0, 0, 0, 5), 3, null);
        assertThat(CompletionCalculator.progress(ps, new UnitCosts(100L, null)).progress()).isEqualTo(1.0);
    }

    @Test
    void levelUpCost_isMultiplierDifferenceTimesUnitCostTimesQuantity() {
        assertThat(CompletionCalculator.levelUpCost(Optional.empty(), Level.L40, 1, 3750)).isEqualTo(30000);
        assertThat(CompletionCalculator.levelUpCost(Optional.of(Level.L20), Level.L40, 2, 100)).isEqualTo(1200);
    }
}
