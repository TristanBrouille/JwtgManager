package com.seckmet.jwtgmanager.tournament.domain;

/** Qualité d'un trio, de la meilleure à la moins bonne. */
public enum TeamQuality {
    /** Fureurs proches et paire complémentaire (2 équilibrés, ou tank + frappeur). */
    IDEAL("Idéal"),
    /** Fureurs proches mais paire non complémentaire. */
    UNMATCHED_PAIR("Paire non complémentaire"),
    /** Fureurs éloignées : formé pour ne laisser aucun dino de côté. */
    UNEVEN("Fureurs éloignées");

    private final String label;

    TeamQuality(String label) {
        this.label = label;
    }

    public String label() { return label; }

    static TeamQuality of(Fighter pairA, Fighter pairB, Fighter single) {
        int max = Math.max(Math.max(pairA.ferocity(), pairB.ferocity()), single.ferocity());
        int min = Math.min(Math.min(pairA.ferocity(), pairB.ferocity()), single.ferocity());
        if (max > min * TeamBuilder.FEROCITY_TOLERANCE) {
            return UNEVEN;
        }
        return Profile.pairWorks(pairA.profile(), pairB.profile()) ? IDEAL : UNMATCHED_PAIR;
    }
}
