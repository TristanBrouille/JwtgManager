package com.seckmet.jwtgmanager.tournament.domain;

import java.util.Arrays;
import java.util.Optional;

/**
 * Ligue d'un tournoi selon la fureur totale de l'équipe (somme des 3 dinos).
 * Une borne haute appartient à sa ligue : 800 est encore « nouveau-né / proie / rare ».
 */
public enum League {
    NEWBORN("Nouveau-né / Proie / Rare", 0, 800),
    HUNTER("Chasseur", 800, 1500),
    PREDATOR("Prédateur", 1500, 3000),
    DOMINANT("Dominant", 3000, Integer.MAX_VALUE);

    private final String label;
    private final int above;
    private final int upTo;

    League(String label, int above, int upTo) {
        this.label = label;
        this.above = above;
        this.upTo = upTo;
    }

    public String label() { return label; }

    /** Fureur minimale exclue (0 inclus pour la première ligue). */
    public int above() { return above; }

    /** Fureur maximale incluse ; {@link Integer#MAX_VALUE} pour la ligue dominant. */
    public int upTo() { return upTo; }

    public boolean capped() {
        return upTo != Integer.MAX_VALUE;
    }

    public static Optional<League> of(int totalFerocity) {
        if (totalFerocity < 0) {
            return Optional.empty();
        }
        return Arrays.stream(values())
                .filter(l -> totalFerocity <= l.upTo && (totalFerocity > l.above || l == NEWBORN))
                .findFirst();
    }
}
