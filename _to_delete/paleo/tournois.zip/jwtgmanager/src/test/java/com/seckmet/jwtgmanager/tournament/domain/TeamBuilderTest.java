package com.seckmet.jwtgmanager.tournament.domain;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static com.seckmet.jwtgmanager.tournament.domain.CreatureClass.*;
import static org.assertj.core.api.Assertions.assertThat;

class TeamBuilderTest {

    /** Fureur ≈ santé × 5/16 + attaque : avec attaque = 0,31 × santé, fureur ≈ 0,6225 × santé. */
    private static Fighter balanced(int id, CreatureClass c, int health) {
        return new Fighter(id, 40, c, health, (int) Math.round(health * 0.31));
    }

    private static TeamBuilder.Stock one(Fighter f) {
        return new TeamBuilder.Stock(f, 1);
    }

    @Test
    void jurassicTeamsPairHerbivoresWithAmphibiansOrCarnivoresWithPterosaurs() {
        List<TeamBuilder.Stock> stocks = List.of(
                one(balanced(1, HERBIVORE, 400)), one(balanced(2, HERBIVORE, 420)),
                one(balanced(3, AMPHIBIAN, 410)), one(balanced(4, CARNIVORE, 400)),
                one(balanced(5, CARNIVORE, 405)));

        List<Team> teams = TeamBuilder.build(Tournament.JURASSIC, stocks);

        assertThat(teams).isNotEmpty();
        for (Team t : teams) {
            Set<CreatureClass> classes = t.members().stream().map(Fighter::creatureClass).collect(Collectors.toSet());
            assertThat(classes).isIn(Set.of(HERBIVORE, AMPHIBIAN), Set.of(CARNIVORE, PTEROSAUR));
        }
        // Sans ptérosaure, les deux carnivores ne forment aucun trio.
        assertThat(teams).allSatisfy(t -> assertThat(t.members()).noneMatch(f -> f.creatureClass() == CARNIVORE));
    }

    @Test
    void teamLandsInTheLeagueOfItsTotalFerocity() {
        List<TeamBuilder.Stock> stocks = List.of(
                one(balanced(1, SURFACE, 400)), one(balanced(2, SURFACE, 400)), one(balanced(3, CAVE, 400)));

        List<Team> teams = TeamBuilder.build(Tournament.AQUATIC, stocks);

        assertThat(teams).hasSize(1);
        Team team = teams.getFirst();
        assertThat(team.totalFerocity()).isBetween(701, 800);
        assertThat(team.league()).isEqualTo(League.NEWBORN);
        assertThat(team.composition()).isEqualTo(new Tournament.Composition(SURFACE, CAVE));
    }

    @Test
    void ferocitiesMustStayClose() {
        List<TeamBuilder.Stock> stocks = List.of(
                one(balanced(1, SNOW, 400)), one(balanced(2, SNOW, 410)), one(balanced(3, CAVERN, 2000)));

        assertThat(TeamBuilder.build(Tournament.CENOZOIC, stocks)).isEmpty();
    }

    @Test
    void pairAcceptsATankWithAStrikerButNotTwoTanks() {
        Fighter tank = new Fighter(1, 40, REEF, 1000, 150);      // fureur 463
        Fighter striker = new Fighter(2, 40, REEF, 400, 340);    // fureur 465
        Fighter tank2 = new Fighter(3, 40, REEF, 1000, 160);     // fureur 473
        Fighter single = balanced(4, CAVE, 750);                 // fureur ≈ 467

        List<Team> withStriker = TeamBuilder.build(Tournament.AQUATIC, List.of(one(tank), one(striker), one(single)));
        assertThat(withStriker).singleElement()
                .satisfies(t -> assertThat(t.members()).contains(tank, striker));

        List<Team> twoTanks = TeamBuilder.build(Tournament.AQUATIC, List.of(one(tank), one(tank2), one(single)));
        assertThat(twoTanks).isEmpty();
    }

    @Test
    void teamsOfALeagueNeverShareASpecimen() {
        List<TeamBuilder.Stock> stocks = List.of(
                new TeamBuilder.Stock(balanced(1, HERBIVORE, 400), 4),
                new TeamBuilder.Stock(balanced(2, AMPHIBIAN, 400), 1));

        List<Team> teams = TeamBuilder.build(Tournament.JURASSIC, stocks);

        // Un seul amphibien : il ne peut servir qu'à un trio (2 herbivores + 1 amphibien).
        assertThat(teams).hasSize(1);
        assertThat(teams.getFirst().members()).filteredOn(f -> f.speciesId() == 1).hasSize(2);
    }

    @Test
    void picksTheStrongestTeamUnderTheLeagueCap() {
        List<TeamBuilder.Stock> stocks = List.of(
                one(balanced(1, CARNIVORE, 400)), one(balanced(2, CARNIVORE, 420)),
                one(balanced(3, CARNIVORE, 300)), one(balanced(4, CARNIVORE, 310)),
                one(balanced(5, PTEROSAUR, 410)), one(balanced(6, PTEROSAUR, 305)));

        List<Team> newborn = TeamBuilder.build(Tournament.JURASSIC, stocks).stream()
                .filter(t -> t.league() == League.NEWBORN).toList();

        assertThat(newborn.getFirst().totalFerocity())
                .isGreaterThanOrEqualTo(newborn.getLast().totalFerocity())
                .isLessThanOrEqualTo(800);
    }
}
