package com.seckmet.jwtgmanager.tournament.exposition;

import com.seckmet.jwtgmanager.tournament.application.TournamentView;

import java.time.Instant;
import java.util.List;

public record TournamentResponse(Instant computedAt, boolean outdated, List<Tournament> tournaments) {

    public record Tournament(String code, String label, List<League> leagues) {
    }

    public record League(String code, String label, int above, Integer upTo, List<Team> teams) {
    }

    public record Team(int rank, int totalFerocity, int ferocityGap, String pairClass, String singleClass,
                       List<Member> members) {
    }

    public record Member(int speciesId, String name, int level, String creatureClass, int health, int attack,
                         int ferocity, String profile, String profileLabel, String portraitUrl) {
    }

    static TournamentResponse of(TournamentView v) {
        return new TournamentResponse(v.computedAt(), v.outdated(), v.tournaments().stream()
                .map(t -> new Tournament(t.code(), t.label(), t.leagues().stream()
                        .map(l -> new League(l.code(), l.label(), l.above(), l.upTo(), l.teams().stream()
                                .map(team -> new Team(team.rank(), team.totalFerocity(), team.ferocityGap(),
                                        team.pairClass(), team.singleClass(), team.members().stream()
                                        .map(m -> new Member(m.speciesId(), m.name(), m.level(), m.creatureClass(),
                                                m.health(), m.attack(), m.ferocity(), m.profile(),
                                                m.profileLabel(), m.portraitUrl()))
                                        .toList()))
                                .toList()))
                        .toList()))
                .toList());
    }
}
