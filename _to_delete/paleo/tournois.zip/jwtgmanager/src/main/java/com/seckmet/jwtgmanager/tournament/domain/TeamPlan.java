package com.seckmet.jwtgmanager.tournament.domain;

import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/** Trios calculés pour un joueur, avec l'empreinte de sa collection au moment du calcul. */
public record TeamPlan(UUID userId, Instant computedAt, String collectionHash, List<Team> teams) {

    public TeamPlan {
        Objects.requireNonNull(userId);
        Objects.requireNonNull(computedAt);
        Objects.requireNonNull(collectionHash);
        teams = List.copyOf(teams);
    }
}
