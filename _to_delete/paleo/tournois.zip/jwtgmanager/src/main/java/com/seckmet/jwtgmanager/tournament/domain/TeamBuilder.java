package com.seckmet.jwtgmanager.tournament.domain;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

/**
 * Compose les meilleurs trios d'un tournoi pour chaque ligue à partir des spécimens du joueur.
 *
 * <ul>
 *   <li>Composition : 2 dinos d'une classe + 1 d'une autre, selon {@link Tournament#compositions()}.</li>
 *   <li>Fureurs équivalentes : le plus fort ne dépasse pas {@value #FEROCITY_TOLERANCE} × le plus faible.</li>
 *   <li>Paire équilibrée : deux profils équilibrés, ou un tank avec un frappeur.</li>
 *   <li>Score = fureur totale − écart de fureur : on vise le haut de la ligue avec un trio homogène.</li>
 * </ul>
 * Chaque ligue reçoit jusqu'à {@value #TEAMS_PER_LEAGUE} trios qui n'utilisent pas deux fois le même
 * spécimen, pour pouvoir enchaîner les combats pendant les temps de récupération.
 */
public final class TeamBuilder {

    public static final double FEROCITY_TOLERANCE = 1.3;
    public static final int TEAMS_PER_LEAGUE = 5;
    private static final int CANDIDATES_PER_LEAGUE = 5_000;

    /** Spécimens identiques (même espèce, même palier) détenus par le joueur. */
    public record Stock(Fighter fighter, int count) {
        public Stock {
            if (count < 0) {
                throw new IllegalArgumentException("Nombre de spécimens négatif");
            }
        }
    }

    private record Candidate(Tournament.Composition composition, Fighter a, Fighter b, Fighter c,
                             int total, int gap) {
        int score() {
            return total - gap;
        }
    }

    private static final Comparator<Candidate> BEST_FIRST = Comparator
            .comparingInt(Candidate::score).reversed()
            .thenComparing(Comparator.comparingInt(Candidate::total).reversed())
            .thenComparingInt(Candidate::gap)
            .thenComparingInt(c -> c.a().speciesId())
            .thenComparingInt(c -> c.b().speciesId())
            .thenComparingInt(c -> c.c().speciesId());

    private TeamBuilder() {
    }

    public static List<Team> build(Tournament tournament, List<Stock> stocks) {
        Map<League, PriorityQueue<Candidate>> byLeague = new EnumMap<>(League.class);
        for (League league : League.values()) {
            byLeague.put(league, new PriorityQueue<>(BEST_FIRST.reversed()));
        }
        Map<Fighter, Integer> owned = new HashMap<>();
        for (Stock s : stocks) {
            if (s.count() > 0) {
                owned.merge(s.fighter(), s.count(), Integer::sum);
            }
        }
        for (Tournament.Composition composition : tournament.compositions()) {
            List<Fighter> pairSide = sortedOf(owned, composition.pair());
            List<Fighter> singleSide = sortedOf(owned, composition.single());
            collect(composition, pairSide, singleSide, owned, byLeague);
        }
        List<Team> teams = new ArrayList<>();
        for (League league : League.values()) {
            List<Candidate> ranked = new ArrayList<>(byLeague.get(league));
            ranked.sort(BEST_FIRST);
            teams.addAll(pick(tournament, league, ranked, owned));
        }
        return teams;
    }

    private static void collect(Tournament.Composition composition, List<Fighter> pairSide,
                                List<Fighter> singleSide, Map<Fighter, Integer> owned,
                                Map<League, PriorityQueue<Candidate>> byLeague) {
        int[] singleFerocity = singleSide.stream().mapToInt(Fighter::ferocity).toArray();
        for (int i = 0; i < pairSide.size(); i++) {
            Fighter a = pairSide.get(i);
            int fa = a.ferocity();
            for (int j = i; j < pairSide.size(); j++) {
                Fighter b = pairSide.get(j);
                int fb = b.ferocity();
                if (fb > fa * FEROCITY_TOLERANCE) {
                    break;
                }
                if (i == j && owned.get(a) < 2 || !Profile.pairWorks(a.profile(), b.profile())) {
                    continue;
                }
                // fa <= fb : le 3e dino doit rester dans la tolérance des deux.
                int low = (int) Math.ceil(fb / FEROCITY_TOLERANCE);
                int high = (int) Math.floor(fa * FEROCITY_TOLERANCE);
                for (int k = lowerBound(singleFerocity, low); k < singleFerocity.length && singleFerocity[k] <= high; k++) {
                    Fighter c = singleSide.get(k);
                    int fc = singleFerocity[k];
                    int total = fa + fb + fc;
                    int gap = Math.max(fb, fc) - Math.min(fa, fc);
                    League.of(total).ifPresent(league -> offer(byLeague.get(league),
                            new Candidate(composition, a, b, c, total, gap)));
                }
            }
        }
    }

    private static void offer(PriorityQueue<Candidate> worstFirst, Candidate candidate) {
        if (worstFirst.size() < CANDIDATES_PER_LEAGUE) {
            worstFirst.add(candidate);
        } else if (BEST_FIRST.compare(candidate, worstFirst.peek()) < 0) {
            worstFirst.poll();
            worstFirst.add(candidate);
        }
    }

    private static List<Team> pick(Tournament tournament, League league, List<Candidate> ranked,
                                   Map<Fighter, Integer> owned) {
        Map<Fighter, Integer> left = new HashMap<>(owned);
        List<Team> teams = new ArrayList<>();
        for (Candidate c : ranked) {
            if (teams.size() == TEAMS_PER_LEAGUE) {
                break;
            }
            Map<Fighter, Integer> needed = new HashMap<>();
            for (Fighter f : List.of(c.a(), c.b(), c.c())) {
                needed.merge(f, 1, Integer::sum);
            }
            boolean available = needed.entrySet().stream()
                    .allMatch(e -> left.getOrDefault(e.getKey(), 0) >= e.getValue());
            if (available) {
                needed.forEach((f, n) -> left.merge(f, -n, Integer::sum));
                teams.add(new Team(tournament, league, teams.size() + 1, c.composition(),
                        List.of(c.a(), c.b(), c.c())));
            }
        }
        return teams;
    }

    private static List<Fighter> sortedOf(Map<Fighter, Integer> owned, CreatureClass creatureClass) {
        return owned.keySet().stream()
                .filter(f -> f.creatureClass() == creatureClass)
                .sorted(Comparator.comparingInt(Fighter::ferocity)
                        .thenComparingInt(Fighter::speciesId)
                        .thenComparingInt(Fighter::level))
                .toList();
    }

    private static int lowerBound(int[] sorted, int value) {
        int lo = 0;
        int hi = sorted.length;
        while (lo < hi) {
            int mid = (lo + hi) >>> 1;
            if (sorted[mid] < value) {
                lo = mid + 1;
            } else {
                hi = mid;
            }
        }
        return lo;
    }
}
