# JWTG Manager — front-end

Front Angular 22 du SaaS JWTG Manager (suivi de complétion des espèces de Jurassic World le jeu).

Avant d'écrire du code ici, suivre le skill `.claude/skills/jwtg-frontend-angular/SKILL.md` :
Signals-First, standalone, zoneless, OnPush, un `.ts` / `.html` / `.scss` séparé par composant, organisation par fonctionnalité, checklist.

- Commandes : `ng serve`, `ng build`, `ng test`, `npx prettier --check .`
- Back : dépôt voisin `../jwtgmanager` (API REST sous `/api/...`).
