# JWTG Manager — back-end

Back Spring Boot 4.2 / Java 27 du SaaS JWTG Manager (suivi de complétion des espèces de Jurassic World le jeu).

Avant d'écrire du code Java ou SQL ici, suivre le skill `.claude/skills/jwtg-backend-ddd/SKILL.md` :
architecture DDD (domain, application, exposition, infrastructure), règles métier, conventions et checklist.

- Build : `./mvnw verify` avec `JAVA_HOME` sur le JDK 27.
- Base : PostgreSQL `pwtgmanagerdb`, schéma dans `src/main/resources/db/jwtg_schema.sql` (`ddl-auto=validate`).
- Front : dépôt voisin `../jwtgmanager_frontend`.
